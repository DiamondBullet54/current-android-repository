package com.example.recipebook

enum class FlavorType {
    savory,
    sweet
}