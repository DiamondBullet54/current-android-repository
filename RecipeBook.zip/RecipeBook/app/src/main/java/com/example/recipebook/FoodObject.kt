package com.example.recipebook

data class FoodObject (
    val name: String,
    val description: String,
    val flavor: FlavorType
)